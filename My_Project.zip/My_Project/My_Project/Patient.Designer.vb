﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Patient
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.btnaddpatient = New System.Windows.Forms.Button()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.pid = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.pdob = New System.Windows.Forms.DateTimePicker()
        Me.pphoto = New System.Windows.Forms.PictureBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pname = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.pgender = New System.Windows.Forms.ComboBox()
        Me.pemail = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.pcontact = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.paddress = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.pcity = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.pcountry = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnreception = New System.Windows.Forms.Button()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.btnclose = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.txtnurse2contact = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtnurse2 = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtnurse1contact = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtnurse1 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtdoccontact = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtdoctor = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.GroupBox2.SuspendLayout()
        CType(Me.pphoto, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnaddpatient
        '
        Me.btnaddpatient.BackColor = System.Drawing.Color.Transparent
        Me.btnaddpatient.FlatAppearance.BorderColor = System.Drawing.Color.Silver
        Me.btnaddpatient.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnaddpatient.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnaddpatient.ForeColor = System.Drawing.Color.Olive
        Me.btnaddpatient.Location = New System.Drawing.Point(518, 253)
        Me.btnaddpatient.Name = "btnaddpatient"
        Me.btnaddpatient.Size = New System.Drawing.Size(121, 28)
        Me.btnaddpatient.TabIndex = 14
        Me.btnaddpatient.Text = "Add"
        Me.btnaddpatient.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.ToolTip1.SetToolTip(Me.btnaddpatient, "Adds the patient (Shift + Enter)")
        Me.btnaddpatient.UseVisualStyleBackColor = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.Filter = "BMP (*.bmp)|*.bmp|JPG (*.jpg)|*.jpg|PNG (*.png)|*.png|Image files (*.bmp;*.jpg;*." & _
    "png)|*.bmp;*.jpg;*.png|All files (*.*)|*.*"
        Me.OpenFileDialog1.FilterIndex = 4
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(341, 16)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(78, 13)
        Me.Label14.TabIndex = 13
        Me.Label14.Text = "Patient picture:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(41, 66)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(57, 13)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "Patient ID:"
        '
        'pid
        '
        Me.pid.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.pid.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.pid.ForeColor = System.Drawing.Color.RoyalBlue
        Me.pid.Location = New System.Drawing.Point(117, 66)
        Me.pid.Name = "pid"
        Me.pid.Size = New System.Drawing.Size(81, 19)
        Me.pid.TabIndex = 3
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.pdob)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.pphoto)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.pid)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.pname)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.pgender)
        Me.GroupBox2.Location = New System.Drawing.Point(24, 13)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(472, 245)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "General information:"
        '
        'pdob
        '
        Me.pdob.Location = New System.Drawing.Point(117, 156)
        Me.pdob.Name = "pdob"
        Me.pdob.Size = New System.Drawing.Size(200, 20)
        Me.pdob.TabIndex = 14
        '
        'pphoto
        '
        Me.pphoto.BackColor = System.Drawing.Color.White
        Me.pphoto.Cursor = System.Windows.Forms.Cursors.Hand
        Me.pphoto.Image = Global.My_project.My.Resources.Resources.download
        Me.pphoto.Location = New System.Drawing.Point(344, 32)
        Me.pphoto.Name = "pphoto"
        Me.pphoto.Size = New System.Drawing.Size(114, 140)
        Me.pphoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pphoto.TabIndex = 13
        Me.pphoto.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(46, 156)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(55, 13)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Birth date:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(26, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Patient name:"
        '
        'pname
        '
        Me.pname.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.pname.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.pname.ForeColor = System.Drawing.Color.RoyalBlue
        Me.pname.Location = New System.Drawing.Point(117, 29)
        Me.pname.Name = "pname"
        Me.pname.Size = New System.Drawing.Size(204, 19)
        Me.pname.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(53, 111)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(45, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Gender:"
        '
        'pgender
        '
        Me.pgender.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.pgender.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.pgender.ForeColor = System.Drawing.Color.RoyalBlue
        Me.pgender.FormattingEnabled = True
        Me.pgender.Items.AddRange(New Object() {"Male", "Female"})
        Me.pgender.Location = New System.Drawing.Point(117, 102)
        Me.pgender.Name = "pgender"
        Me.pgender.Size = New System.Drawing.Size(81, 26)
        Me.pgender.TabIndex = 5
        '
        'pemail
        '
        Me.pemail.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.pemail.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.pemail.ForeColor = System.Drawing.Color.RoyalBlue
        Me.pemail.Location = New System.Drawing.Point(29, 154)
        Me.pemail.Name = "pemail"
        Me.pemail.Size = New System.Drawing.Size(414, 19)
        Me.pemail.TabIndex = 13
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(26, 138)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(75, 13)
        Me.Label12.TabIndex = 12
        Me.Label12.Text = "Email address:"
        '
        'pcontact
        '
        Me.pcontact.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.pcontact.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.pcontact.ForeColor = System.Drawing.Color.RoyalBlue
        Me.pcontact.Location = New System.Drawing.Point(239, 105)
        Me.pcontact.Name = "pcontact"
        Me.pcontact.Size = New System.Drawing.Size(204, 19)
        Me.pcontact.TabIndex = 11
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(236, 89)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(85, 13)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "Contact number:"
        '
        'paddress
        '
        Me.paddress.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.paddress.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.paddress.ForeColor = System.Drawing.Color.RoyalBlue
        Me.paddress.Location = New System.Drawing.Point(29, 105)
        Me.paddress.Name = "paddress"
        Me.paddress.Size = New System.Drawing.Size(204, 19)
        Me.paddress.TabIndex = 9
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(26, 89)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(48, 13)
        Me.Label10.TabIndex = 8
        Me.Label10.Text = "Address:"
        '
        'pcity
        '
        Me.pcity.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.pcity.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.pcity.ForeColor = System.Drawing.Color.RoyalBlue
        Me.pcity.Location = New System.Drawing.Point(239, 56)
        Me.pcity.Name = "pcity"
        Me.pcity.Size = New System.Drawing.Size(204, 19)
        Me.pcity.TabIndex = 5
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(236, 40)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(27, 13)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "City:"
        '
        'pcountry
        '
        Me.pcountry.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.pcountry.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.pcountry.ForeColor = System.Drawing.Color.RoyalBlue
        Me.pcountry.Location = New System.Drawing.Point(29, 56)
        Me.pcountry.Name = "pcountry"
        Me.pcountry.Size = New System.Drawing.Size(204, 19)
        Me.pcountry.TabIndex = 3
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(26, 40)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(46, 13)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Country:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.pemail)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.pcontact)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.paddress)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.pcity)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.pcountry)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Location = New System.Drawing.Point(24, 264)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(472, 196)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Contact details:"
        '
        'btnreception
        '
        Me.btnreception.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnreception.Location = New System.Drawing.Point(168, 59)
        Me.btnreception.Name = "btnreception"
        Me.btnreception.Size = New System.Drawing.Size(135, 33)
        Me.btnreception.TabIndex = 13
        Me.btnreception.Text = "Finance"
        Me.btnreception.UseVisualStyleBackColor = True
        '
        'btnclear
        '
        Me.btnclear.BackColor = System.Drawing.Color.Transparent
        Me.btnclear.FlatAppearance.BorderColor = System.Drawing.Color.Silver
        Me.btnclear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnclear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnclear.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnclear.Location = New System.Drawing.Point(518, 295)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(121, 28)
        Me.btnclear.TabIndex = 15
        Me.btnclear.Text = "Clear"
        Me.btnclear.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnclear.UseVisualStyleBackColor = False
        '
        'btnclose
        '
        Me.btnclose.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.btnclose.FlatAppearance.BorderColor = System.Drawing.Color.Silver
        Me.btnclose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnclose.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnclose.ForeColor = System.Drawing.Color.Red
        Me.btnclose.Location = New System.Drawing.Point(518, 329)
        Me.btnclose.Name = "btnclose"
        Me.btnclose.Size = New System.Drawing.Size(121, 28)
        Me.btnclose.TabIndex = 16
        Me.btnclose.Text = "Close"
        Me.btnclose.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnclose.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.Button5)
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.btnreception)
        Me.Panel1.Location = New System.Drawing.Point(675, 253)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(320, 104)
        Me.Panel1.TabIndex = 17
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(168, 15)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(135, 33)
        Me.Button1.TabIndex = 19
        Me.Button1.Text = "Nurses"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(12, 59)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(135, 33)
        Me.Button5.TabIndex = 18
        Me.Button5.Text = "Doctors"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(12, 15)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(135, 33)
        Me.Button3.TabIndex = 17
        Me.Button3.Text = "Patients Log"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtnurse2contact)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.txtnurse2)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.txtnurse1contact)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.txtnurse1)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.txtdoccontact)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.txtdoctor)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Location = New System.Drawing.Point(518, 13)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(477, 222)
        Me.GroupBox3.TabIndex = 14
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Staff details:"
        '
        'txtnurse2contact
        '
        Me.txtnurse2contact.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtnurse2contact.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.txtnurse2contact.ForeColor = System.Drawing.Color.RoyalBlue
        Me.txtnurse2contact.Location = New System.Drawing.Point(239, 150)
        Me.txtnurse2contact.Name = "txtnurse2contact"
        Me.txtnurse2contact.Size = New System.Drawing.Size(204, 19)
        Me.txtnurse2contact.TabIndex = 15
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(236, 134)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(85, 13)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Contact number:"
        '
        'txtnurse2
        '
        Me.txtnurse2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtnurse2.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.txtnurse2.ForeColor = System.Drawing.Color.RoyalBlue
        Me.txtnurse2.Location = New System.Drawing.Point(29, 150)
        Me.txtnurse2.Name = "txtnurse2"
        Me.txtnurse2.Size = New System.Drawing.Size(204, 19)
        Me.txtnurse2.TabIndex = 13
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(26, 134)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(92, 13)
        Me.Label16.TabIndex = 12
        Me.Label16.Text = "Nurse 2 assigned:"
        '
        'txtnurse1contact
        '
        Me.txtnurse1contact.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtnurse1contact.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.txtnurse1contact.ForeColor = System.Drawing.Color.RoyalBlue
        Me.txtnurse1contact.Location = New System.Drawing.Point(239, 105)
        Me.txtnurse1contact.Name = "txtnurse1contact"
        Me.txtnurse1contact.Size = New System.Drawing.Size(204, 19)
        Me.txtnurse1contact.TabIndex = 11
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(236, 89)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(85, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Contact number:"
        '
        'txtnurse1
        '
        Me.txtnurse1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtnurse1.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.txtnurse1.ForeColor = System.Drawing.Color.RoyalBlue
        Me.txtnurse1.Location = New System.Drawing.Point(29, 105)
        Me.txtnurse1.Name = "txtnurse1"
        Me.txtnurse1.Size = New System.Drawing.Size(204, 19)
        Me.txtnurse1.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(26, 89)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(92, 13)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Nurse 1 assigned:"
        '
        'txtdoccontact
        '
        Me.txtdoccontact.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtdoccontact.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.txtdoccontact.ForeColor = System.Drawing.Color.RoyalBlue
        Me.txtdoccontact.Location = New System.Drawing.Point(239, 56)
        Me.txtdoccontact.Name = "txtdoccontact"
        Me.txtdoccontact.Size = New System.Drawing.Size(204, 19)
        Me.txtdoccontact.TabIndex = 5
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(236, 40)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(85, 13)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "Contact number:"
        '
        'txtdoctor
        '
        Me.txtdoctor.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtdoctor.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.txtdoctor.ForeColor = System.Drawing.Color.RoyalBlue
        Me.txtdoctor.Location = New System.Drawing.Point(29, 56)
        Me.txtdoctor.Name = "txtdoctor"
        Me.txtdoctor.Size = New System.Drawing.Size(204, 19)
        Me.txtdoctor.TabIndex = 3
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(26, 40)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(87, 13)
        Me.Label15.TabIndex = 2
        Me.Label15.Text = "Doctor assigned:"
        '
        'Patient
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1076, 608)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.btnaddpatient)
        Me.Controls.Add(Me.btnclose)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.btnclear)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Patient"
        Me.Text = "Patient"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.pphoto, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents pphoto As System.Windows.Forms.PictureBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents pid As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents pname As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents pgender As System.Windows.Forms.ComboBox
    Friend WithEvents pemail As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents pcontact As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents paddress As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents pcity As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents pcountry As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents pdob As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnreception As System.Windows.Forms.Button
    Friend WithEvents btnclear As System.Windows.Forms.Button
    Friend WithEvents btnclose As System.Windows.Forms.Button
    Friend WithEvents btnaddpatient As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents txtnurse2contact As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtnurse2 As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtnurse1contact As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtnurse1 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtdoccontact As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtdoctor As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
End Class
