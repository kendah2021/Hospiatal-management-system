﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Registeration
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Registeration))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnregister = New System.Windows.Forms.Button()
        Me.btnregistercancel = New System.Windows.Forms.Button()
        Me.lblusername = New System.Windows.Forms.Label()
        Me.lblpassword = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtenterusername = New System.Windows.Forms.TextBox()
        Me.txtenterpassword = New System.Windows.Forms.TextBox()
        Me.txtreenterpassword = New System.Windows.Forms.TextBox()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(171, -8)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(170, 102)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 54
        Me.PictureBox1.TabStop = False
        '
        'btnregister
        '
        Me.btnregister.BackColor = System.Drawing.Color.Aquamarine
        Me.btnregister.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnregister.Location = New System.Drawing.Point(78, 299)
        Me.btnregister.Margin = New System.Windows.Forms.Padding(2)
        Me.btnregister.Name = "btnregister"
        Me.btnregister.Size = New System.Drawing.Size(112, 42)
        Me.btnregister.TabIndex = 53
        Me.btnregister.Text = "Register"
        Me.btnregister.UseVisualStyleBackColor = False
        '
        'btnregistercancel
        '
        Me.btnregistercancel.BackColor = System.Drawing.Color.DarkSalmon
        Me.btnregistercancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnregistercancel.Location = New System.Drawing.Point(299, 299)
        Me.btnregistercancel.Margin = New System.Windows.Forms.Padding(2)
        Me.btnregistercancel.Name = "btnregistercancel"
        Me.btnregistercancel.Size = New System.Drawing.Size(112, 42)
        Me.btnregistercancel.TabIndex = 52
        Me.btnregistercancel.Text = "Cancel"
        Me.btnregistercancel.UseVisualStyleBackColor = False
        '
        'lblusername
        '
        Me.lblusername.AutoSize = True
        Me.lblusername.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblusername.Location = New System.Drawing.Point(76, 108)
        Me.lblusername.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblusername.Name = "lblusername"
        Me.lblusername.Size = New System.Drawing.Size(143, 18)
        Me.lblusername.TabIndex = 58
        Me.lblusername.Text = "Enter User Name "
        '
        'lblpassword
        '
        Me.lblpassword.AutoSize = True
        Me.lblpassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpassword.Location = New System.Drawing.Point(76, 174)
        Me.lblpassword.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblpassword.Name = "lblpassword"
        Me.lblpassword.Size = New System.Drawing.Size(128, 18)
        Me.lblpassword.TabIndex = 57
        Me.lblpassword.Text = "Enter Password"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(76, 233)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(154, 18)
        Me.Label2.TabIndex = 55
        Me.Label2.Text = "Re Enter Password"
        '
        'txtenterusername
        '
        Me.txtenterusername.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtenterusername.Location = New System.Drawing.Point(78, 134)
        Me.txtenterusername.Margin = New System.Windows.Forms.Padding(2)
        Me.txtenterusername.Name = "txtenterusername"
        Me.txtenterusername.Size = New System.Drawing.Size(334, 26)
        Me.txtenterusername.TabIndex = 62
        '
        'txtenterpassword
        '
        Me.txtenterpassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtenterpassword.Location = New System.Drawing.Point(78, 196)
        Me.txtenterpassword.Margin = New System.Windows.Forms.Padding(2)
        Me.txtenterpassword.Name = "txtenterpassword"
        Me.txtenterpassword.Size = New System.Drawing.Size(334, 26)
        Me.txtenterpassword.TabIndex = 61
        '
        'txtreenterpassword
        '
        Me.txtreenterpassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtreenterpassword.Location = New System.Drawing.Point(78, 256)
        Me.txtreenterpassword.Margin = New System.Windows.Forms.Padding(2)
        Me.txtreenterpassword.Name = "txtreenterpassword"
        Me.txtreenterpassword.Size = New System.Drawing.Size(334, 26)
        Me.txtreenterpassword.TabIndex = 60
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.Location = New System.Drawing.Point(221, 362)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(53, 20)
        Me.LinkLabel1.TabIndex = 63
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Login"
        '
        'Registeration
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(489, 410)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.txtreenterpassword)
        Me.Controls.Add(Me.txtenterpassword)
        Me.Controls.Add(Me.txtenterusername)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblpassword)
        Me.Controls.Add(Me.lblusername)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnregistercancel)
        Me.Controls.Add(Me.btnregister)
        Me.Name = "Registeration"
        Me.Text = "Registeration"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents btnregister As System.Windows.Forms.Button
    Friend WithEvents btnregistercancel As System.Windows.Forms.Button
    Friend WithEvents lblusername As System.Windows.Forms.Label
    Friend WithEvents lblpassword As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtenterusername As System.Windows.Forms.TextBox
    Friend WithEvents txtenterpassword As System.Windows.Forms.TextBox
    Friend WithEvents txtreenterpassword As System.Windows.Forms.TextBox
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
End Class
