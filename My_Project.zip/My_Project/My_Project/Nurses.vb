﻿Imports System.Data.SqlClient

Public Class Nurses

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
        Reception.Show()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim command As New SqlCommand("insert into nurses(id, name, email, address, phone) values(@id, @name, @email, @address, @phone)", Conn)
        command.Parameters.Add("@id", SqlDbType.VarChar).Value = nid.Text
        command.Parameters.Add("@name", SqlDbType.VarChar).Value = nname.Text
        command.Parameters.Add("@email", SqlDbType.VarChar).Value = nemail.Text
        command.Parameters.Add("@address", SqlDbType.VarChar).Value = naddress.Text
        command.Parameters.Add("@phone", SqlDbType.VarChar).Value = nphone.Text


        Conn.Open()
        If command.ExecuteNonQuery() = 1 Then

            MessageBox.Show("New Nurse Added")
            nid.Text = ""
            nname.Text = ""
            nemail.Text = ""
            naddress.Text = ""
            nphone.Text = ""



        Else

            MessageBox.Show("Nurse Not Added")

        End If

        Conn.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        nid.Text = ""
        nname.Text = ""
        nemail.Text = ""
        naddress.Text = ""
        nphone.Text = ""


    End Sub
End Class