﻿Imports System.Data.SqlClient

Public Class Registeration

    Private Sub btnregister_Click(sender As Object, e As EventArgs) Handles btnregister.Click
        If txtenterpassword.Text.Trim() = txtreenterpassword.Text.Trim() Then

            Dim command As New SqlCommand("insert into tbl_accounts(username, password) values(@username,@password)", Conn)

            command.Parameters.Add("@username", SqlDbType.VarChar).Value = txtenterusername.Text
            command.Parameters.Add("@password", SqlDbType.VarChar).Value = txtenterpassword.Text


            Conn.Open()
            If command.ExecuteNonQuery() = 1 Then

                MessageBox.Show("New user added sucessfully!")
            Else
                MessageBox.Show("Signup Unsucessfully!")

            End If

            Conn.Close()
        Else
            MsgBox("confirmation password do not match")
        End If
        txtenterusername.Text = ""
        txtenterpassword.Text = ""
        txtreenterpassword.Text = ""
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Login.Show()
        Me.Hide()
    End Sub

    Private Sub btnregistercancel_Click(sender As Object, e As EventArgs) Handles btnregistercancel.Click
        Me.Close()
            Reception.Show()

    End Sub
End Class