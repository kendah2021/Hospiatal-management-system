﻿Imports System.Data.SqlClient

Public Class Finance


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim command As New SqlCommand("insert into Finance(Bill_To, Patient_Address, Phone, Email, Invoice_Number, Admission_Date, Discharged_Date, Doctor_Assigned, Date, Services_Performed, Medication, Charges) values(@Bill_To, @Patient_Address, @Phone, @Email, @Invoice_Number, @Admission_Date, @Discharged_Date, @Doctor_Assigned, @Date, @Services_Performed, @Medication, @Charges)", Conn)
        command.Parameters.Add("@Bill_To", SqlDbType.VarChar).Value = txtbillto.Text
        command.Parameters.Add("@Patient_Address", SqlDbType.VarChar).Value = txtpatientadd.Text
        command.Parameters.Add("@Phone", SqlDbType.Int).Value = txtphone.Text
        command.Parameters.Add("@Email", SqlDbType.VarChar).Value = txtemail.Text
        command.Parameters.Add("@Invoice_Number", SqlDbType.VarChar).Value = txtinvoice.Text
        command.Parameters.Add("@Admission_Date", SqlDbType.Date).Value = addmissiopn.Value
        command.Parameters.Add("@Discharged_Date", SqlDbType.Date).Value = discharged.Value
        command.Parameters.Add("@Doctor_Assigned", SqlDbType.VarChar).Value = txtdoctor.Text
        command.Parameters.Add("@Date", SqlDbType.VarChar).Value = txtdate1.Text


        command.Parameters.Add("@Services_Performed", SqlDbType.VarChar).Value = txtservices1.Text

        command.Parameters.Add("@Medication", SqlDbType.VarChar).Value = txtmed1.Text
        command.Parameters.Add("@Charges", SqlDbType.VarChar).Value = txtcharges.Text


        Conn.Open()
        If command.ExecuteNonQuery() = 1 Then

            MessageBox.Show("New Invoice Added")
            txtbillto.Text = ""
            txtpatientadd.Text = ""
            txtphone.Text = ""
            txtemail.Text = ""
            txtinvoice.Text = ""
            addmissiopn.Text = ""

            discharged.Text = ""
            txtdoctor.Text = ""
            txtdate1.Text = ""
            txtservices1.Text = ""
            txtmed1.Text = ""
            txtcharges.Text = ""
            f1.Text = ""



        Else

            MessageBox.Show("Invoice Not Added")

        End If

        Conn.Close()
    End Sub

   
   
    Private Sub f1_TextChanged(sender As Object, e As EventArgs) Handles f1.TextChanged
        Dim c1, total As Integer
        c1 = f1.Text
        total = c1
        txtcharges.Text = total
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
        Reception.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        txtbillto.Text = ""
        txtpatientadd.Text = ""
        txtphone.Text = ""
        txtemail.Text = ""
        txtinvoice.Text = ""
        addmissiopn.Text = ""

        discharged.Text = ""
        txtdoctor.Text = ""
        txtdate1.Text = ""
        txtservices1.Text = ""
        txtmed1.Text = ""
        txtcharges.Text = ""
        f1.Text = ""

    End Sub

    Private Sub txtphone_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtphone.KeyPress
        Dim ch As Char = e.KeyChar
        If Not Char.IsDigit(ch) AndAlso Asc(ch) <> 8 Then
            e.Handled = True
            MessageBox.Show("Only number is valid")
        End If
    End Sub

    Private Sub txtinvoice_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtinvoice.KeyPress
        Dim ch As Char = e.KeyChar
        If Not Char.IsDigit(ch) AndAlso Asc(ch) <> 8 Then
            e.Handled = True
            MessageBox.Show("Only number is valid")
        End If
    End Sub

    Private Sub f1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles f1.KeyPress
        Dim ch As Char = e.KeyChar
        If Not Char.IsDigit(ch) AndAlso Asc(ch) <> 8 Then
            e.Handled = True
            MessageBox.Show("Only number is valid")
        End If
    End Sub

    Private Sub txtphone_TextChanged(sender As Object, e As EventArgs) Handles txtphone.TextChanged

    End Sub
End Class