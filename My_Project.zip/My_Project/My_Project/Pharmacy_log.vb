﻿Imports System.Data.SqlClient

Public Class Pharmacy_log

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Close()
        Reception.Show()
    End Sub

    Private Sub loadData(sql As String, dtg As DataGridView)
        Dim da As New SqlDataAdapter
        Dim dt As New DataTable

        Try
            Conn.Open()


            cmd = New SqlCommand

            With cmd
                .Connection = Conn
                .CommandText = sql
            End With
            da.SelectCommand = cmd
            da.Fill(dt)

            dtg.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            Conn.Close()
            da.Dispose()
        End Try

    End Sub

    Private Sub Pharmacy_log_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Sql = "SELECT * FROM pharmacy"
        loadData(Sql, DataGridView1)


        Dim adapter As New SqlDataAdapter(cmd)

        Dim dt As New DataTable()



        adapter.Fill(dt)



    End Sub

    
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim cid As Integer = txtsearch.Text
        Dim command As New SqlCommand("select * from pharmacy where Patient_id = '" & txtsearch.Text & "'", Conn)
        Dim sda As New SqlDataAdapter(command)
        Dim dt As New DataTable
        sda.Fill(dt)
        DataGridView1.DataSource = dt
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If MessageBox.Show("Confirm delete?", "Delete Prescription", MessageBoxButtons.YesNo) = DialogResult.Yes Then
            Dim pid As Integer = txtsearch.Text
            Conn.Open()
            Dim command As New SqlCommand("DELETE Pharmacy where Patient_id = '" & pid & "'", Conn)
            command.ExecuteNonQuery()
            MessageBox.Show(" Prescription Deleted Successfully")
            Conn.Close()
            DataGridView1.DataSource = dt
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Sql = "SELECT * FROM Pharmacy"
        loadData(Sql, DataGridView1)


        Dim adapter As New SqlDataAdapter(cmd)

        Dim dt As New DataTable()



        adapter.Fill(dt)
    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub txtsearch_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtsearch.KeyPress
        Dim ch As Char = e.KeyChar
        If Not Char.IsDigit(ch) AndAlso Asc(ch) <> 8 Then
            e.Handled = True
            MessageBox.Show("Only number is valid")
        End If
    End Sub

   
End Class