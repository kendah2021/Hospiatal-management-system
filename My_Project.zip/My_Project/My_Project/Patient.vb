﻿Imports System.Data.SqlClient
Imports System.IO

Public Class Patient

    Private Sub pphoto_Click(sender As Object, e As EventArgs) Handles pphoto.Click
        Dim opf As New OpenFileDialog


        opf.Filter = "Choose Image(*.JPG;*.PNG;*.GIF)|*.jpg;*.png;*.gif"


        If opf.ShowDialog = Windows.Forms.DialogResult.OK Then


            pphoto.Image = Image.FromFile(opf.FileName)


        End If

    End Sub

    
  



    Private Sub btnreception_Click(sender As Object, e As EventArgs) Handles btnreception.Click
        Finance.Show()
        Me.Hide()
    End Sub

    
   
    Private Sub Button3_Click_1(sender As Object, e As EventArgs) Handles Button3.Click
        Patients_details.Show()
        Me.Hide()

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Doctors.Show()
        Me.Hide()

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles btnaddpatient.Click
        pdob.Format = DateTimePickerFormat.Custom
        pdob.CustomFormat = "dd/mm/yyyy"
        Dim command As New SqlCommand("insert into tbl_patient(name, id, gender, BirthDate, Image, country, city, address, contact, email, Doctor, Doc_Contact, Nurse_1, Nurse_1_Contact, Nurse_2, Nurse_2_Contact ) values(@name, @id, @gender, @BirthDate, @Image, @country, @city, @address, @contact, @email, @Doctor, @Doc_Contact, @Nurse_1, @Nurse_1_Contact, @Nurse_2, @Nurse_2_Contact)", Conn)
        Dim ms As New MemoryStream
        pphoto.Image.Save(ms, pphoto.Image.RawFormat)
        command.Parameters.Add("@name", SqlDbType.VarChar).Value = pname.Text
        command.Parameters.Add("@id", SqlDbType.VarChar).Value = pid.Text
        command.Parameters.Add("@gender", SqlDbType.VarChar).Value = pgender.Text
        command.Parameters.Add("@BirthDate", SqlDbType.Date).Value = pdob.Value
        command.Parameters.Add("@Image", SqlDbType.Image).Value = ms.ToArray()
        command.Parameters.Add("@country", SqlDbType.VarChar).Value = pcountry.Text
        command.Parameters.Add("@city", SqlDbType.VarChar).Value = pcity.Text
        command.Parameters.Add("@address", SqlDbType.VarChar).Value = paddress.Text
        command.Parameters.Add("@contact", SqlDbType.VarChar).Value = pcontact.Text
        command.Parameters.Add("@email", SqlDbType.VarChar).Value = pemail.Text
        command.Parameters.Add("@Doctor", SqlDbType.VarChar).Value = txtdoctor.Text
        command.Parameters.Add("@Doc_Contact", SqlDbType.VarChar).Value = txtdoccontact.Text
        command.Parameters.Add("@Nurse_1", SqlDbType.VarChar).Value = txtnurse1.Text
        command.Parameters.Add("@Nurse_1_Contact", SqlDbType.VarChar).Value = txtnurse1contact.Text
        command.Parameters.Add("@Nurse_2", SqlDbType.VarChar).Value = txtnurse2.Text
        command.Parameters.Add("@Nurse_2_Contact", SqlDbType.VarChar).Value = txtnurse2contact.Text


        Conn.Open()
        If command.ExecuteNonQuery() = 1 Then

            MessageBox.Show("New patient Added")
            pname.Text = ""
            pid.Text = ""
            pgender.Text = ""
            pdob.Text = ""
            pphoto.Text = ""
            pcountry.Text = ""
            pcity.Text = ""
            paddress.Text = ""
            pcontact.Text = ""
            pemail.Text = ""
            txtdoccontact.Text = ""
            txtdoctor.Text = ""
            txtnurse1.Text = ""
            txtnurse1contact.Text = ""
            txtnurse2.Text = ""
            txtnurse2contact.Text = ""

        Else

            MessageBox.Show("patient Not Added")

        End If

        Conn.Close()
    End Sub

    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles btnclose.Click
        Me.Close()
        Reception.Show()

    End Sub

    Private Sub Button4_Click_1(sender As Object, e As EventArgs) Handles btnclear.Click
        pname.Text = ""
        pid.Text = ""
        pgender.Text = ""
        pdob.Text = ""
        pphoto.Text = ""
        pcountry.Text = ""
        pcity.Text = ""
        paddress.Text = ""
        pcontact.Text = ""
        pemail.Text = ""
        txtdoccontact.Text = ""
        txtdoctor.Text = ""
        txtnurse1.Text = ""
        txtnurse1contact.Text = ""
        txtnurse2.Text = ""
        txtnurse2contact.Text = ""



    End Sub

   
   
    Private Sub txtdoctor_TextChanged(sender As Object, e As EventArgs) Handles txtdoctor.TextChanged

    End Sub
End Class