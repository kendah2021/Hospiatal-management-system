﻿Imports System.Data.SqlClient

Public Class Doctors

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
        Reception.Show()
    End Sub

    Private Sub btnaddDoctor_Click(sender As Object, e As EventArgs) Handles btnaddDoctor.Click

        Dim command As New SqlCommand("insert into doctors(id, name, address, email, contact, dessignation) values(@id, @name, @address, @email, @contact, @dessignation)", Conn)
        command.Parameters.Add("@id", SqlDbType.VarChar).Value = did.Text
        command.Parameters.Add("@name", SqlDbType.VarChar).Value = dname.Text
        command.Parameters.Add("@address", SqlDbType.VarChar).Value = daddress.Text
        command.Parameters.Add("@email", SqlDbType.VarChar).Value = demail.Text
        command.Parameters.Add("@contact", SqlDbType.VarChar).Value = dphone.Text
        command.Parameters.Add("@dessignation", SqlDbType.VarChar).Value = ddesignation.Text


        Conn.Open()
        If command.ExecuteNonQuery() = 1 Then

            MessageBox.Show("New Doctor Added")
            did.Text = ""
            dname.Text = ""
            daddress.Text = ""
            demail.Text = ""
            dphone.Text = ""
            ddesignation.Text = ""



        Else

            MessageBox.Show("Doctor Not Added")

        End If

        Conn.Close()
    End Sub

    Private Sub Doctors_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Doctors_log.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Patients_details.Show()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Pharmacy_log.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Nurses_log.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        did.Text = ""
        dname.Text = ""
        daddress.Text = ""
        demail.Text = ""
        dphone.Text = ""
        ddesignation.Text = ""


    End Sub
End Class