﻿Imports System.Data.SqlClient

Public Class Pharmacy

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
        Reception.Show()

    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
     
        Dim command As New SqlCommand("insert into pharmacy(Patient_ID, Patient_Name, Tab_Name, Dose_in_mg, Number_of_Tab, Daily_Dose, Issued_Date, Expiration_Date) values(@Patient_ID, @Patient_Name, @Tab_Name, @Dose_in_mg, @Number_of_Tab, @Daily_Dose, @Issued_Date, @Expiration_Date)", Conn)
        command.Parameters.Add("@Patient_ID", SqlDbType.VarChar).Value = phid.Text
        command.Parameters.Add("@Patient_Name", SqlDbType.VarChar).Value = phname.Text
        command.Parameters.Add("@Tab_Name", SqlDbType.VarChar).Value = phtab.Text
        command.Parameters.Add("@Dose_in_mg", SqlDbType.VarChar).Value = phdosemg.Text
        command.Parameters.Add("@Number_of_Tab", SqlDbType.VarChar).Value = phnumberoftablet.Text
        command.Parameters.Add("@Daily_Dose", SqlDbType.VarChar).Value = phdailydose.Text
        command.Parameters.Add("@Issued_Date", SqlDbType.Date).Value = phissuedate.Value
        command.Parameters.Add("@Expiration_Date", SqlDbType.Date).Value = phexpirationdate.Value


        Conn.Open()
        If command.ExecuteNonQuery() = 1 Then

            MessageBox.Show("New Prescription Added")
            phid.Text = ""
            phname.Text = ""
            phdosemg.Text = ""
            phtab.Text = ""
            phnumberoftablet.Text = ""
            phdailydose.Text = ""
         

        Else

            MessageBox.Show("prescription Not Added")

        End If

        Conn.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        phid.Text = ""
        phname.Text = ""
        phdosemg.Text = ""
        phtab.Text = ""
        phnumberoftablet.Text = ""
        phdailydose.Text = ""


    End Sub
End Class