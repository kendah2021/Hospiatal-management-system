﻿Imports System.Data.SqlClient

Public Class Login

    Sub LoginSystem()
        If txtusername.Text = "" Then
            MsgBox("Username is Required!", MsgBoxStyle.Critical)
            txtusername.Focus()
        ElseIf txtpassword.Text = "" Then
            MsgBox("Password is Required!", MsgBoxStyle.Critical)
            txtpassword.Focus()
        Else
            Try
                ConnecDatabase()
                Sql = "Select * From tbl_accounts Where Username = @Username And Password = @Password;"
                cmd = New SqlCommand
                With cmd
                    .Connection = Conn
                    .CommandText = Sql
                    .Parameters.Clear()
                    .Parameters.AddWithValue("@Username", txtusername.Text)
                    .Parameters.AddWithValue("@Password", txtpassword.Text)
                    .ExecuteNonQuery()
                End With
                da = New SqlDataAdapter
                dt = New DataTable
                da.SelectCommand = cmd
                da.Fill(dt)
            Catch ex As SqlException
                MsgBox(ex.Message)
            Finally
                Conn.Close()
                da.Dispose()
                If dt.Rows.Count > 0 Then
                    Dim Username, Password As String
                    Username = dt.Rows(0).Item("Username")
                    Password = dt.Rows(0).Item("Password")
                    If txtusername.Text = Username And txtpassword.Text = Password Then

                        MsgBox("Welcome " & txtusername.Text)
                        txtusername.Text = ""
                        txtpassword.Text = ""

                        Me.Hide()

                        Reception.Show()
                    Else
                        MessageBox.Show("Signup Unsucessfully!")
                    End If

                End If
            End Try
        End If
    End Sub


    Private Sub cmdLogin_Click(sender As Object, e As EventArgs) Handles cmdLogin.Click
        Loginsystem()
    End Sub


    Private Sub txtPassword_KeyDown(sender As Object, e As KeyEventArgs) Handles txtpassword.KeyDown
        If e.KeyCode = 13 Then
            Loginsystem()
        End If
    End Sub

    Private Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click
        Dim RESULT = MessageBox.Show("Do you wish to cancel Page", "close form", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If RESULT = (Windows.Forms.DialogResult.Yes) Then
            Application.Exit()
        End If
    End Sub



  
    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.CheckState = CheckState.Checked Then
            txtpassword.UseSystemPasswordChar = False
        Else

            txtpassword.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub txtusername_TextChanged(sender As Object, e As EventArgs) Handles txtusername.TextChanged

    End Sub
End Class
