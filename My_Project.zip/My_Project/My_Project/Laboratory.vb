﻿Imports System.Data.SqlClient

Public Class Laboratory

    Private Sub btnaddDoctor_Click(sender As Object, e As EventArgs) Handles btnaddDoctor.Click

        Dim command As New SqlCommand("insert into laboratory(Patient_ID, Lab_Technician_Name, Patient_Name, Test_Type, Test_Name, Test_Result) values(@Patient_ID, @Lab_Technician_Name, @Patient_Name, @Test_Type, @Test_Name, @Test_Result)", Conn)
        command.Parameters.Add("@Patient_ID", SqlDbType.VarChar).Value = labid.Text
        command.Parameters.Add("@Lab_Technician_Name", SqlDbType.VarChar).Value = labtechname.Text
        command.Parameters.Add("@Patient_Name", SqlDbType.VarChar).Value = labpatientname.Text
        command.Parameters.Add("@Test_Type", SqlDbType.VarChar).Value = testtype.Text
        command.Parameters.Add("@Test_Name", SqlDbType.VarChar).Value = testname.Text
        command.Parameters.Add("@Test_Result", SqlDbType.VarChar).Value = testresult.Text


        Conn.Open()
        If command.ExecuteNonQuery() = 1 Then

            MessageBox.Show("New Lab details Added")
            labid.Text = ""
            labtechname.Text = ""
            labpatientname.Text = ""
            testtype.Text = ""
            testname.Text = ""
            testresult.Text = ""



        Else

            MessageBox.Show("Lab details Not Added")

        End If

        Conn.Close()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Laboratory_log.Show()
    End Sub

    Private Sub Laboratory_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
        Reception.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        labid.Text = ""
        labtechname.Text = ""
        labpatientname.Text = ""
        testtype.Text = ""
        testname.Text = ""
        testresult.Text = ""


    End Sub
End Class