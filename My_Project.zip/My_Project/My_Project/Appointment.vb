﻿Imports System.Data.SqlClient

Public Class Appointment

    Private Sub Button3_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim command As New SqlCommand("insert into Appointments(Patient_ID, Patient_Name, Case_Type, Doctor, Date, Time) values(@Patient_ID, @Patient_Name, @Case_Type, @Doctor, @Date, @Time)", Conn)
        command.Parameters.Add("@Patient_ID", SqlDbType.VarChar).Value = txtid.Text
        command.Parameters.Add("@Patient_Name", SqlDbType.VarChar).Value = txtname.Text
        command.Parameters.Add("@Case_Type", SqlDbType.VarChar).Value = txtcase.Text
        command.Parameters.Add("@Doctor", SqlDbType.VarChar).Value = txtdoctor.Text
        command.Parameters.Add("@Date", SqlDbType.Date).Value = txtdate.Value
        command.Parameters.Add("@Time", SqlDbType.VarChar).Value = txttime.Text


        Conn.Open()
        If command.ExecuteNonQuery() = 1 Then

            MessageBox.Show("New Appointment Added")
            txtid.Text = ""
            txtname.Text = ""
            txtcase.Text = ""
            txtdoctor.Text = ""
            txtdate.Text = ""
            txttime.Text = ""



        Else

            MessageBox.Show("Appointment Not Added")

        End If

        Conn.Close()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Appointments_log.Show()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Patients_details.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        txtid.Text = ""
        txtname.Text = ""
        txtcase.Text = ""
        txtdoctor.Text = ""
        txtdate.Text = ""
        txttime.Text = ""

    End Sub

    Private Sub Button3_Click_1(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
        Reception.Show()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Pharmacy_log.Show()
    End Sub

    Private Sub Appointment_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class